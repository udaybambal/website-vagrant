# linux-website-vagrant

This is a completed project for the tutorial at:

<https://www.tutorialworks.com/linux-vm-vagrant>

This demo shows how to create a Linux virtual machine with Vagrant, and provision it, by installing Apache HTTP Server and deploying a simple static website.

For more DevOps and Linux tutorials, visit <https://www.tutorialworks.com>.
